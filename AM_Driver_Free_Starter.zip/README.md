# AM Driver Free — početna stvarna verzija

Ovo nije samo mockup. Driver app se spaja na Supabase bazu, svaki vozač ima svoj login,
vidi samo svoje vožnje i može mijenjati status vožnje.

## Što je besplatno za početak
- PWA/web aplikacija (driver.html)
- Supabase Free projekt
- Hosting na GitHub Pages / Netlify / Vercel free tier
- Google Maps linkovi
- WhatsApp i CALL gumbi preko telefona

## 1. Otvori Supabase račun
1. Napravi novi projekt na supabase.com.
2. SQL Editor → New query.
3. Kopiraj cijeli sadržaj `supabase_schema.sql` i pokreni Run.
4. Project Settings → API.
5. Kopiraj Project URL i anon/public key.
6. Otvori `config.js` i zamijeni:
   - PASTE_SUPABASE_URL_HERE
   - PASTE_SUPABASE_ANON_KEY_HERE

VAŽNO: Nemoj stavljati `service_role` key u config.js. Koristi samo anon/public key.

## 2. Dodaj vozača
1. Supabase → Authentication → Users → Add user.
2. Unesi njegov email i privremenu lozinku.
3. Kopiraj User UUID.
4. Table Editor → drivers → Insert row:
   id = User UUID
   full_name = ime vozača
   phone = broj
   vehicle = Mercedes E-Class / V-Class / Economy Sedan
   registration = registracija

## 3. Dodaj vožnju
Table Editor → trips → Insert row:
- booking_no: AM-0001
- pickup_at: datum + vrijeme
- pickup: Keight Hotel, Opatija
- destination: Zagreb Airport
- passenger_name: John Smith
- passenger_phone: +385...
- passengers: 2
- flight_no: LH1234
- source: Direct / Hotel / Corporate
- driver_id: UUID vozača
- status: assigned

Vozač se prijavi i odmah vidi vožnju.

## 4. Stavi online besplatno
Uploadaj sve datoteke iz ovog foldera na GitHub Pages, Netlify ili Vercel.
Pošalji vozačima link `.../driver.html`.

Na Androidu ili iPhoneu mogu koristiti "Add to Home Screen" i AM Driver se ponaša kao aplikacija.

## Trenutne funkcije
- login vozača
- svaki vozač vidi samo svoje vožnje
- pickup/destination
- passenger + phone
- flight number
- source
- call / WhatsApp / Google Maps
- Accept
- On the way
- Arrived
- Passenger onboard
- Complete trip
- statusi se spremaju u zajedničku bazu
- PWA / Add to Home Screen

## Sigurnost
Baza koristi Row Level Security (RLS). Vozač smije čitati i mijenjati samo svoje trips.
Admin tajni ključ se ne nalazi u aplikaciji.

## Sljedeća faza
Pravi AM Admin portal:
- New Trip forma
- drag/drop dodjela vozača
- live status svih vožnji
- automatski WhatsApp / email
- partner/hotel/corporate source
- izvještaji
