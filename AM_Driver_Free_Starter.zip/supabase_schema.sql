
-- AM Driver Free / Supabase schema
create extension if not exists pgcrypto;

create table if not exists public.drivers (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  vehicle text,
  registration text,
  is_active boolean default true,
  created_at timestamptz default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  booking_no text not null unique,
  pickup_at timestamptz not null,
  pickup text not null,
  destination text not null,
  passenger_name text not null,
  passenger_phone text,
  passengers integer default 1,
  flight_no text,
  source text default 'Direct',
  notes text,
  driver_id uuid references public.drivers(id) on delete set null,
  status text not null default 'assigned'
    check (status in ('assigned','accepted','on_the_way','arrived','on_board','completed','cancelled')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.drivers enable row level security;
alter table public.trips enable row level security;

drop policy if exists "drivers can read own profile" on public.drivers;
create policy "drivers can read own profile"
on public.drivers for select
to authenticated
using (id = auth.uid());

drop policy if exists "drivers can read own trips" on public.trips;
create policy "drivers can read own trips"
on public.trips for select
to authenticated
using (driver_id = auth.uid());

drop policy if exists "drivers can update own trips" on public.trips;
create policy "drivers can update own trips"
on public.trips for update
to authenticated
using (driver_id = auth.uid())
with check (driver_id = auth.uid());

-- For the first free version, Admin uses the Supabase dashboard to add trips
-- OR admin.html with the service role is NOT used client-side for security.
-- Create driver users in Authentication > Users, then insert matching driver profile:
-- insert into public.drivers (id, full_name, phone, vehicle, registration)
-- values ('USER_UUID','Driver Name','+385...','Mercedes E-Class','RI ...');
