// AM Driver Free — Supabase configuration
// Paste values from Supabase: Project Settings → API
window.AM_CONFIG = {
  SUPABASE_URL: "PASTE_SUPABASE_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_SUPABASE_ANON_KEY_HERE"
};
